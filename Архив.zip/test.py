import math
print(math.__doc__)
math.sqrt.__doc__

class Test:
    """Класс Test используется для демонстрации docstring."""

    def first(self):
        """Описывает метод first и демонстрирует перенос строки 
        документации.
        """
        


print(__doc__)
print(tricky_func.__doc__)
print(Test.__doc__)
print(Test.first.__doc__) 
